<?php
namespace App\Enums;

interface Gender
{
    const MALE   = 5;
    const FEMALE = 10;
}
