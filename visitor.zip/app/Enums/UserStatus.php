<?php
/**
 * Created by PhpStorm.
 * User: dipok
 * Date: 17/4/20
 * Time: 12:47 PM
 */

namespace App\Enums;

interface UserStatus
{
    const ACTIVE   = 5;
    const INACTIVE = 10;
}
